(() => {
  'use strict';
  if (globalThis.__waygroundPurpleAssistantLoaded) return;
  globalThis.__waygroundPurpleAssistantLoaded = true;

  const DEFAULTS = {enabled:true, useAI:false, useWeb:false, visionEnabled:true, uiLanguage:'ru', opacity:0.92, hasKey:false};
  let settings = {...DEFAULTS};
  let current = null;
  let signature = '';
  let requestNo = 0;
  let lastScan = 0;
  let scheduled = 0;
  let overlay = null;
  let bars = [];
  const cache = new Map();
  let status = {state:'starting', message:'Подключение к странице…', source:'', explanation:'', question:'', imageRelevant:false};
  const MESSAGES = {
    ru:{off:'Расширение выключено.',searching:'Ожидание вопроса с вариантами…',scanning:'Вопрос распознан. Проверяю…',thinking:'ИИ анализирует вопрос…',vision:'ИИ анализирует изображение…',needVision:'Чтобы распознавать фото, включите ИИ, анализ изображений и укажите API-ключ.',noImages:'Вопрос требует распознавания изображения, но подходящее фото не найдено.',needsKey:'Для незнакомых вопросов укажите API-ключ.',unknown:'Встроенная база не знает уверенного ответа.',uncertain:'Недостаточно данных для уверенного ответа.',apiError:'Не удалось получить ответ ИИ.',badKey:'API-ключ отклонён (401).',rateLimit:'Лимит API или недостаточно средств (429).',timeout:'Превышено время ожидания API.',found:(n,ids)=>`Найдено ответов: ${n}. Варианты: ${ids}`},
    en:{off:'Assistant disabled.',searching:'Waiting for a question with choices…',scanning:'Question detected. Checking…',thinking:'AI is analyzing the question…',vision:'AI is analyzing the image…',needVision:'To recognize images, turn on AI and image analysis and add an API key.',noImages:'The question requires visual recognition, but no suitable image was found.',needsKey:'Add an API key for unfamiliar questions.',unknown:'The local knowledge base does not have a confident answer.',uncertain:'Not enough evidence for a confident answer.',apiError:'Unable to get an AI response.',badKey:'API key rejected (401).',rateLimit:'API usage limit or insufficient credits (429).',timeout:'The API request timed out.',found:(n,ids)=>`Answers found: ${n}. Choices: ${ids}`},
    lv:{off:'Asistents ir izslēgts.',searching:'Gaidu jautājumu ar atbilžu variantiem…',scanning:'Jautājums atpazīts. Pārbaudu…',thinking:'MI analizē jautājumu…',vision:'MI analizē attēlu…',needVision:'Lai atpazītu attēlus, ieslēdz MI un attēlu analīzi un ievadi API atslēgu.',noImages:'Jautājumam nepieciešams attēls, bet piemērots attēls nav atrasts.',needsKey:'Nezināmiem jautājumiem ievadi API atslēgu.',unknown:'Lokālajā zināšanu bāzē nav pārliecinošas atbildes.',uncertain:'Nepietiek informācijas drošai atbildei.',apiError:'Neizdevās iegūt MI atbildi.',badKey:'API atslēga noraidīta (401).',rateLimit:'API limits vai nepietiek kredīta (429).',timeout:'Pārsniegts API pieprasījuma laiks.',found:(n,ids)=>`Atrastas atbildes: ${n}. Varianti: ${ids}`}
  };
  const t = (key,...args) => { const value=(MESSAGES[settings.uiLanguage]||MESSAGES.ru)[key];return typeof value==='function'?value(...args):value; };


  function visible(el, rect) {
    if (!(el instanceof HTMLElement)) return false;
    if (el.closest('#wgpa-overlay, script, style, header, nav, footer, [aria-hidden="true"]')) return false;
    const r = rect || el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1 || r.right <= 0 || r.bottom <= 0 || r.top >= innerHeight || r.left >= innerWidth) return false;
    const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && Number(cs.opacity) > 0.02;
  }
  function getText(el) {
    const raw = (el.innerText || el.textContent || '').trim();
    return raw.split('\n').map(v => v.replace(/\s+/g,' ').trim())
      .filter(v => v && !/^(?:[1-8]|[A-H]|[1-8][.)])$/.test(v))
      .join(' ').replace(/\s+/g,' ').trim().slice(0, 350);
  }
  function hasFill(el) {
    const st = getComputedStyle(el);
    const bg = st.backgroundColor;
    return !!bg && !/transparent|rgba\([^)]*,\s*0(?:\.0+)?\)/.test(bg) && bg !== 'rgba(0, 0, 0, 0)';
  }
  const overlap = (a,b) => {
    const x = Math.max(0, Math.min(a.right,b.right)-Math.max(a.left,b.left));
    const y = Math.max(0, Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
    return x*y / Math.max(1, Math.min(a.width*a.height,b.width*b.height));
  };
  function findChoices() {
    const W = innerWidth, H = innerHeight;
    if (W < 320 || H < 300) return null;
    const elements = document.querySelectorAll('button, [role="button"], [class*="option" i], [class*="answer" i], [data-testid], div, li');
    const candidates = [];
    for (let i = 0; i < Math.min(elements.length, 7500); i++) {
      const el = elements[i];
      if (!(el instanceof HTMLElement) || el.id === 'wgpa-overlay' || el.closest('#wgpa-overlay')) continue;
      const r = el.getBoundingClientRect();
      if (r.width < W*0.145 || r.width > W*0.72 || r.height < 54 || r.height > H*0.67 ||
          r.top < H*0.27 || r.top > H*0.91 || !visible(el,r)) continue;
      const txt = getText(el);
      const isVisual = !!el.querySelector('img,canvas,svg,[style*="background-image"]');
      if ((!txt && !isVisual) || txt.length > 200 || /^(?:next|следующий|turpinat|continue|submit|проверить)$/i.test(txt)) continue;
      const filled = hasFill(el);
      const style = getComputedStyle(el);
      const clickable = el.matches('button,[role="button"], [data-testid*="answer" i], [data-testid*="option" i]');
      const score = (filled ? 6 : 0) + (clickable ? 5 : 0) +
        (style.cursor === 'pointer' ? 2 : 0) +
        (r.height > H*0.14 ? 1 : 0) +
        (r.width > W*0.20 ? 2 : 0) + Math.min(2, txt.length/50);
      candidates.push({el, rect:r, text:txt, score});
    }
    if (candidates.length < 2) return null;
    // Оставить наиболее подходящий DOM-узел в каждом визуальном прямоугольнике.
    candidates.sort((a,b) => b.score-a.score);
    const unique = [];
    for (const c of candidates) {
      if (unique.some(u => overlap(u.rect,c.rect) > 0.77)) continue;
      unique.push(c);
      if (unique.length > 90) break;
    }
    // Соседние карточки имеют близкие границы и похожие размеры.
    let best = null, bestScore = -Infinity;
    for (const anchor of unique) {
      const line = unique.filter(c =>
        Math.abs(c.rect.top-anchor.rect.top) < Math.min(34, H*0.045) &&
        Math.abs(c.rect.height-anchor.rect.height) < Math.max(50, anchor.rect.height*0.35) &&
        Math.abs(c.rect.width-anchor.rect.width) < Math.max(90, anchor.rect.width*0.37));
      const row = [];
      for (const c of line.sort((a,b)=> a.rect.left-b.rect.left)) {
        if (row.every(existing => overlap(existing.rect,c.rect) < 0.3)) row.push(c);
      }
      if (row.length < 2 || row.length > 6) continue;
      const occupied = row.reduce((s,c) => s+c.rect.width, 0) / W;
      if (occupied < 0.35) continue;
      const score = row.length*20 + occupied*10 + row.reduce((s,c)=>s+c.score,0)*0.5 + anchor.rect.top/H*4;
      if (score > bestScore) { bestScore=score; best=row; }
    }
    return best && best.length >= 2 ? best : null;
  }
  function findQuestion(choices) {
    if (!choices) return '';
    const top = Math.min(...choices.map(c=>c.rect.top));
    let best = null, bestScore = -Infinity;
    const nodes = document.querySelectorAll('h1,h2,h3,h4,[role="heading"],p,span,div,section');
    for (let i=0; i<Math.min(nodes.length,9000); i++) {
      const el = nodes[i];
      if (!(el instanceof HTMLElement) || choices.some(c=>c.el.contains(el))) continue;
      if (el.closest('#wgpa-overlay, nav, header, footer')) continue;
      const r = el.getBoundingClientRect();
      if (r.top < innerHeight*.06 || r.bottom > top-12 || r.height < 14 ||
          r.height > innerHeight*.25 || r.width < 40 || r.width > innerWidth*.94 || !visible(el,r)) continue;
      const txt = getText(el);
      if (txt.length < 7 || txt.length > 240 || txt.split(' ').length > 45) continue;
      const st = getComputedStyle(el);
      const font = parseFloat(st.fontSize) || 16;
      if (font < 17) continue;
      const center = (r.left + r.right)/2;
      const centerDist = Math.abs(center-innerWidth*.5) / innerWidth;
      const proximity = Math.max(0, 1-(top-r.bottom)/innerHeight);
      const isHeading = el.matches('h1,h2,h3,h4,[role="heading"]');
      const score = (/[?？]|\b(kas|kurš|kāda|which|what|how|что|какой|сколько|kads|cik)\b/i.test(txt) ? 8:0) +
        (isHeading ? 7:0) + (Math.min(font,40)-16)*0.55 + proximity*12 - centerDist*28 -
        (txt.length > 160 ? 8:0);
      if (score > bestScore) { best={text:txt,el}; bestScore=score; }
    }
    return best && bestScore > 2 ? best.text : '';
  }
  // Определяем режим по тексту задания и доступным HTML-признакам.
  // Если тип вопроса не обозначен явно, сохраняем unknown: ИИ проверит
  // каждый вариант отдельно, а не будет принудительно искать один ответ.
  function detectChoiceMode(question, choices) {
    const q = question.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    if (/\b(select|choose|check|tick)\s+all\b|\bmultiple\s+(?:correct\s+)?answers?\b|\bmore than one\b|(?:все|всех)\s+(?:правильн|подходящ|верн)|(?:выбер|отмет|укаж)\w*\s+(?:все|нескольк)|нескольк\w*\s+(?:правильн\w*\s+)?(?:ответ|вариант)|izvel\w*\s+(?:vis|vairak)|atzim\w*\s+(?:vis|vairak)|vairak\w*\s+(?:pareiz\w*\s+)?atbild|visas\s+pareizas\s+atbild/.test(q)) return 'multiple';
    if (/\b(select|choose)\s+(?:only\s+)?one\b|\bsingle[ -]choice\b|выбер\w*\s+(?:один|только один)|один\s+правильн\w*\s+ответ|izvel\w*\s+vienu|viena\s+pareiz\w*\s+atbild/.test(q)) return 'single';
    const hasChecks = choices.some(c => c.el.matches('[role="checkbox"],input[type="checkbox"]') ||
      !!c.el.querySelector('input[type="checkbox"],[role="checkbox"]'));
    if (hasChecks) return 'multiple';
    const hasRadios = choices.some(c => c.el.matches('[role="radio"],input[type="radio"]') ||
      !!c.el.querySelector('input[type="radio"],[role="radio"]'));
    if (hasRadios) return 'single';
    return 'unknown';
  }
  // Conservative trigger: mere presence of an illustration does NOT activate vision.
  // Only questions specifically asking about a picture/diagram or its contents do.
  function asksAboutImage(question) {
    const q = question.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
    return /(?:\b(?:image|picture|photo|photograph|diagram|figure|illustration|screenshot|pictured|depicted|shown in the|look at the image|identify the picture|identify the object|visual)\b|изображ|фотограф|фото|картинк|рисунк|схем[еау]|на фото|на рисунке|показан.{0,15}(?:ниже|выше)|что на (?:этом|данном) снимке|\batt[eē]l|\bfotogr[aā]f|\bbild[eē]|\bsh[eē]m|\bredzam|\bpar[aā]d[iī]t|\batpaz[iī]st|kas (?:ir )?att[eē]lots|p[eē]c att[eē]la)/i.test(q);
  }
  function imageInfo(el) {
    if (el instanceof HTMLImageElement) return {src:el.currentSrc||el.src||'', token:el.currentSrc||el.src||el.alt||''};
    if (el instanceof HTMLCanvasElement) return {src:'', token:`canvas:${el.width}x${el.height}`};
    if (el instanceof SVGElement) return {src:'', token:`svg:${el.outerHTML.slice(0,140)}`};
    const bg=getComputedStyle(el).backgroundImage||'';
    const m=bg.match(/url\(["']?(https?:[^"')]+)["']?\)/i);
    return {src:m?.[1]||'',token:m?.[1]||''};
  }
  function discoverImages(choices) {
    const top=Math.min(...choices.map(c=>c.rect.top));
    const selectors='img,svg,canvas,[style*="background-image"],[class*="image" i]';
    const elements=document.querySelectorAll(selectors);
    const found=[];
    for(let i=0;i<Math.min(elements.length,1600);i++) {
      const el=elements[i];
      if(!(el instanceof HTMLElement||el instanceof SVGElement))continue;
      const r=el.getBoundingClientRect();
      if(r.width<64||r.height<62||r.width*r.height<4500||!visibleImage(el,r))continue;
      const choiceIndex=choices.findIndex(c=>c.el.contains(el));
      if(choiceIndex<0 && (r.bottom>top+8 || r.top<innerHeight*.055))continue;
      const info=imageInfo(el);
      if(!(el instanceof HTMLImageElement||el instanceof HTMLCanvasElement||el instanceof SVGElement||info.src))continue;
      found.push({rect:{left:r.left,top:r.top,width:r.width,height:r.height},
        label:choiceIndex<0?'Question image':`Answer card ${choiceIndex+1}`,
        element:el,src:info.src,token:info.token,priority:(choiceIndex<0?1000:0)+Math.min(800,r.width*r.height/300)});
    }
    found.sort((a,b)=>b.priority-a.priority);
    const selected=[];
    for(const item of found){
      const rect={left:item.rect.left,top:item.rect.top,right:item.rect.left+item.rect.width,
        bottom:item.rect.top+item.rect.height,width:item.rect.width,height:item.rect.height};
      if(selected.some(s=>{
        const rr={left:s.rect.left,top:s.rect.top,right:s.rect.left+s.rect.width,
          bottom:s.rect.top+s.rect.height,width:s.rect.width,height:s.rect.height};
        return overlap(rect,rr)>.70;
      }))continue;
      selected.push(item);if(selected.length>=5)break;
    }
    return selected;
  }
  function visibleImage(el,r) {
    if(el.closest('#wgpa-overlay,header,nav,footer,[aria-hidden="true"]'))return false;
    if(r.right<=0||r.bottom<=0||r.left>=innerWidth||r.top>=innerHeight)return false;
    const style=getComputedStyle(el);
    return style.visibility!=='hidden'&&style.display!=='none'&&Number(style.opacity)>.02;
  }
  function readQuestion() {
    const choices=findChoices();
    if(!choices)return null;
    const question=findQuestion(choices);
    if(!question)return null;
    const imageRelevant=asksAboutImage(question);
    const options=choices.map((c,i)=>c.text||`[Image option ${i+1}]`);
    if(new Set(options.map(v=>v.toLowerCase())).size!==options.length)return null;
    const imageRegions=imageRelevant?discoverImages(choices):[];
    return {question,options,choices,imageRelevant,imageRegions,mode:detectChoiceMode(question,choices)};
  }
  async function cropImageRegions(screenshot,regions) {
    const shot=new Image();
    await new Promise((resolve,reject)=>{shot.onload=resolve;shot.onerror=reject;shot.src=screenshot;});
    const scaleX=shot.naturalWidth/innerWidth,scaleY=shot.naturalHeight/innerHeight;
    const cropped=[];
    for(const region of regions) {
      const r=region.rect,pad=9;
      const x=Math.max(0,Math.floor((r.left-pad)*scaleX));
      const y=Math.max(0,Math.floor((r.top-pad)*scaleY));
      const right=Math.min(shot.naturalWidth,Math.ceil((r.left+r.width+pad)*scaleX));
      const bottom=Math.min(shot.naturalHeight,Math.ceil((r.top+r.height+pad)*scaleY));
      if(right-x<38||bottom-y<38)continue;
      const sw=right-x,sh=bottom-y,factor=Math.min(1,900/Math.max(sw,sh));
      const canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(sw*factor));canvas.height=Math.max(1,Math.round(sh*factor));
      canvas.getContext('2d',{alpha:false}).drawImage(shot,x,y,sw,sh,0,0,canvas.width,canvas.height);
      const dataUrl=canvas.toDataURL('image/jpeg',.80);
      if(dataUrl.length<1800000)cropped.push({label:region.label,dataUrl});
      canvas.width=canvas.height=0;
    }
    return cropped;
  }
  async function cropDOMImage(region) {
    // Same-origin images can be cropped without screen permissions.
    const el=region.element;
    try {
      if(!(el instanceof HTMLImageElement)&&!(el instanceof HTMLCanvasElement))return null;
      if(el instanceof HTMLImageElement&&(!el.complete||!el.naturalWidth))return null;
      const w=el instanceof HTMLImageElement?el.naturalWidth:el.width;
      const h=el instanceof HTMLImageElement?el.naturalHeight:el.height;
      if(w<30||h<30)return null;
      const f=Math.min(1,900/Math.max(w,h)),canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(w*f));canvas.height=Math.max(1,Math.round(h*f));
      const ctx=canvas.getContext('2d',{alpha:false});
      ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height);
      ctx.drawImage(el,0,0,canvas.width,canvas.height);
      const dataUrl=canvas.toDataURL('image/jpeg',.80);
      canvas.width=canvas.height=0;
      return dataUrl.length<1800000?{label:region.label,dataUrl}:null;
    }catch{return null;} // Cross-origin images cannot be read by canvas.
  }
  async function getVisionImages(data) {
    if(!data.imageRelevant||!settings.visionEnabled||!settings.useAI||!settings.hasKey)
      return {images:[],imageUrls:[]};
    let images=[];
    if(data.imageRegions.length){
      try {
        const resp=await chrome.runtime.sendMessage({type:'CAPTURE_VIEWPORT'});
        if(resp?.ok&&resp.dataUrl)images=await cropImageRegions(resp.dataUrl,data.imageRegions);
      }catch{/* Fall back to same-origin image elements / public HTTPS URLs. */}
      if(!images.length){
        const local=await Promise.all(data.imageRegions.map(cropDOMImage));
        images=local.filter(Boolean);
      }
    }
    const imageUrls=images.length?[]:data.imageRegions
      .filter(r=>typeof r.src==='string'&&/^https:\/\//.test(r.src))
      .map(r=>({label:r.label,url:r.src}));
    return {images,imageUrls};
  }
  function removeBars() {
    for (const bar of bars) bar.el.remove();
    bars = [];
  }
  function root() {
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'wgpa-overlay';
      overlay.setAttribute('aria-hidden', 'true');
      overlay.style.cssText = 'position:fixed!important;inset:0!important;pointer-events:none!important;z-index:2147483646!important;overflow:hidden!important;';
      document.documentElement.appendChild(overlay);
    }
    return overlay;
  }
  function transparentColor(color) {
    if (!color || color === 'transparent') return true;
    if (/^rgba?\(/i.test(color)) {
      const v = color.match(/[\d.]+/g) || [];
      return v.length === 4 && Number(v[3]) === 0;
    }
    return false;
  }
  function cardPaint(el) {
    // Часто карточка имеет CSS-градиент; backgroundColor тогда прозрачен.
    // Ищем первый реальный фон элемента или одного из его родителей.
    for (let node=el, depth=0; node instanceof HTMLElement && depth<5; node=node.parentElement,depth++) {
      const css = getComputedStyle(node);
      const gradient = css.backgroundImage?.includes('gradient(') ? css.backgroundImage : 'none';
      if (gradient !== 'none' || !transparentColor(css.backgroundColor)) {
        return {color:transparentColor(css.backgroundColor) ? 'transparent' : css.backgroundColor,
          image:gradient, rect:node.getBoundingClientRect()};
      }
    }
    return {color:'#777',image:'none',rect:el.getBoundingClientRect()};
  }
  function positionBars() {
    if (!current || !bars.length) return;
    for (const {index, el} of bars) {
      const choice = current.choices[index];
      if (!choice || !choice.el.isConnected) { el.style.display='none'; continue; }
      const r = choice.el.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) { el.style.display='none'; continue; }
      const left = Math.round(r.left+Math.max(5,Math.min(11,r.width*.02)));
      const top = Math.round(r.top+Math.min(14,r.height*.10));
      el.style.display='block';
      el.style.left = `${left}px`;
      el.style.top = `${top}px`;
      el.style.height = `${Math.round(Math.max(18,Math.min(54,r.height*.14)))}px`;
      const paint=cardPaint(choice.el);
      // Повторяем фон карточки в координатах её прямоугольника.
      // brightness даёт лишь небольшой оттенок того же цвета.
      el.style.setProperty('background-color',paint.color,'important');
      el.style.setProperty('background-image',paint.image,'important');
      if (paint.image !== 'none') {
        el.style.setProperty('background-size',`${Math.round(paint.rect.width)}px ${Math.round(paint.rect.height)}px`,'important');
        el.style.setProperty('background-position',`${Math.round(paint.rect.left-left)}px ${Math.round(paint.rect.top-top)}px`,'important');
      }
    }
  }
  function showAnswer(indices) {
    removeBars();
    if (!current || !settings.enabled) return;
    for (const index of [...new Set(indices)]) {
      if (!Number.isInteger(index) || !current.choices[index]) continue;
      const el = document.createElement('div');
      el.style.cssText = `position:fixed!important;width:2px!important;border-radius:3px!important;opacity:${settings.opacity}!important;filter:brightness(.86)!important;box-shadow:none!important;pointer-events:none!important;`;
      root().appendChild(el);
      bars.push({index,el});
    }
    positionBars();
  }
  function state(next) { status={...status,...next}; }
  function aiFailure(error) {
    const raw=String(error||'');
    if(/401|api.key|API-ключ|atslēga|key rejected/i.test(raw))return t('badKey');
    if(/429|quota|rate limit|недостаточно средств|лимит/i.test(raw))return t('rateLimit');
    if(/timeout|abort|времени ожидания|30 секунд/i.test(raw))return t('timeout');
    return t('apiError');
  }
  async function getSettings() {
    try {
      const result = await chrome.runtime.sendMessage({type:'GET_SETTINGS'});
      if (result?.ok) settings={...DEFAULTS,...result.settings};
    } catch(e) { state({state:'error',message:`Ошибка настроек: ${String(e).slice(0,80)}`}); }
  }
  async function analyze(data,sig,token) {
    let result=null;
    // Text-only local rules must never claim to have examined a relevant picture.
    if(!data.imageRelevant)result=globalThis.QuizKnowledge?.answer(data.question,data.options,data.mode,settings.uiLanguage);
    if(!result && data.imageRelevant && (!settings.useAI||!settings.hasKey||!settings.visionEnabled)) {
      state({state:'unknown',message:t('needVision'),question:data.question,imageRelevant:true});return;
    }
    if(!result && settings.useAI && settings.hasKey) {
      state({state:'thinking',message:t(data.imageRelevant?'vision':'thinking'),source:'',explanation:'',imageRelevant:data.imageRelevant});
      try {
        const vision=await getVisionImages(data);
        if(signature!==sig||requestNo!==token)return;
        if(data.imageRelevant&&!vision.images.length&&!vision.imageUrls.length){
          state({state:'unknown',message:t('noImages'),question:data.question,imageRelevant:true});return;
        }
        const response=await chrome.runtime.sendMessage({type:'ASK_AI',payload:{
          question:data.question,options:data.options,mode:data.mode,imageRelevant:data.imageRelevant,
          images:vision.images,imageUrls:vision.imageUrls
        }});
        if(response?.ok)result=response.answer;
        else if(signature===sig&&requestNo===token)
          state({state:'error',message:aiFailure(response?.error),explanation:''});
      }catch(e){if(signature===sig&&requestNo===token)state({state:'error',message:aiFailure(e),explanation:''});}
    }
    if(signature!==sig||requestNo!==token||!settings.enabled)return;
    if(result&&result.indices.length&&result.confidence>=.66){
      cache.set(sig,result);if(cache.size>80)cache.delete(cache.keys().next().value);
      showAnswer(result.indices);
      state({state:'ready',message:t('found',result.indices.length,result.indices.map(i=>i+1).join(', ')),
        source:result.source,explanation:result.explanation,question:data.question,imageRelevant:data.imageRelevant});
    }else if(status.state!=='error'){
      removeBars();
      state({state:'unknown',message:result?t('uncertain'):(data.imageRelevant?t('needVision'):
        (settings.useAI&&!settings.hasKey?t('needsKey'):t('unknown'))),
        source:'',explanation:'',question:data.question,imageRelevant:data.imageRelevant});
    }
  }
  function scan() {
    lastScan=Date.now();
    if (!settings.enabled) {
      removeBars(); current=null; signature='';
      state({state:'off',message:t('off'),question:'',source:'',explanation:'',imageRelevant:false});
      return;
    }
    const data=readQuestion();
    if (!data) {
      if (signature) { requestNo++;signature='';current=null;removeBars(); }
      state({state:'searching',message:t('searching'),question:'',source:'',explanation:'',imageRelevant:false});
      return;
    }
    const sig=JSON.stringify([data.mode,data.question,...data.options,data.imageRelevant,...data.imageRegions.map(r=>r.label+':'+r.token)]);
    if (sig===signature) {
      // Карточки могут сместиться или быть заменены во время анимации.
      if (current) current.choices=data.choices;
      positionBars();
      return;
    }
    signature=sig;current=data;const token=++requestNo;
    removeBars();state({state:'scanning',message:t('scanning'),question:data.question,source:'',explanation:'',imageRelevant:data.imageRelevant});
    if (cache.has(sig)) {
      const prev=cache.get(sig);showAnswer(prev.indices);
      state({state:'ready',message:t('found',prev.indices.length,prev.indices.map(i=>i+1).join(', ')),source:prev.source,
        explanation:prev.explanation,question:data.question,imageRelevant:data.imageRelevant});
    } else analyze(data,sig,token);
  }
  function scheduleScan() {
    if (scheduled) clearTimeout(scheduled);
    scheduled=setTimeout(()=>{scheduled=0;scan();},300);
  }
  function shouldScanMutation(records) {
    return records.some(m=> !(overlay && (overlay===m.target || overlay.contains(m.target))) );
  }
  chrome.runtime.onMessage.addListener((message,_sender,respond)=> {
    if (message?.type==='GET_STATUS') {respond({...status,enabled:settings.enabled,hasKey:settings.hasKey,useAI:settings.useAI});return;}
    if (message?.type==='SETTINGS_CHANGED') {
      getSettings().then(()=>{requestNo++;signature='';current=null;removeBars();scheduleScan();});
      respond({ok:true});return;
    }
    if (message?.type==='RESCAN') {signature='';requestNo++;removeBars();scheduleScan();respond({ok:true});}
  });
  const observer = new MutationObserver(records=>{if(shouldScanMutation(records))scheduleScan();});
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true,attributes:false});
  addEventListener('resize',()=>{positionBars();scheduleScan();},{passive:true});
  addEventListener('scroll',positionBars,{passive:true,capture:true});
  // Запасной опрос: сайты на Canvas или с нестандартными событиями могут не менять DOM.
  setInterval(()=>{if(Date.now()-lastScan>1600)scan();},2000);
  getSettings().then(scheduleScan);
})();
