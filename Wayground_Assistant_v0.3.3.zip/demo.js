'use strict';
const questions=[
  {q:'Kas ir 3-2-1 princips?',a:['3 serveri vienā vietā','1 kopija vienā diskā','3 kopijas, 2 datu nesēji, 1 citā vietā','2 kopijas, 3 datu nesēji, 1 citā vietā']},
  {q:'Kāda ir datora barošanas bloka galvenā funkcija?',a:['Pārvērst maiņstrāvu līdzstrāvā','Glabāt operētājsistēmu','Paātrināt procesora takts frekvenci','Palielināt operatīvo atmiņu']},
  {q:'Kas ir 80 PLUS sertifikācija barošanas blokam?',a:['Procesora saderības standarts','Dzesēšanas trokšņa mērījums','Kabeļu garuma standarts','Energoefektivitātes jeb lietderības rādītājs']},
  {q:'Какой разъём питания обычно используется для материнской платы ATX?',a:['6-pin PCIe','24-pin (20+4)','SATA 15-pin','Molex 4-pin']},
  {q:'Что означает модульный блок питания?',a:['У него нет вентилятора','Он работает только на 12 В','Его кабели можно отсоединять','Он не требует розетки']},
  {q:'Kuri spriegumi ir standarta ATX barošanas blokam? Izvēlies visas pareizās atbildes.',a:['+3,3 V','+5 V','+12 V','+9 V']},
  {q:'Что за разъём изображён на фотографии?',a:['SATA Power 15-pin','ATX 24-pin (20+4)','PCIe 6-pin','Molex 4-pin'],image:'images/atx24-demo.svg'},
  {q:'Какой разъём питания обычно используется для материнской платы ATX?',a:['SATA Power','ATX 24-pin (20+4)','PCIe 6-pin','Molex 4-pin'],image:'images/cloud-demo.svg'}
];
let n=0;function render(){
  const item=questions[n];document.getElementById('quizQuestion').textContent=item.q;
  document.getElementById('questionImage').src=item.image||'images/cloud-demo.svg';
  document.getElementById('answers').replaceChildren(...item.a.map((t,i)=>{
    const b=document.createElement('div');b.className='answer';b.dataset.num=i+1;b.textContent=t;return b;
  }));
}
document.getElementById('next').addEventListener('click',()=>{n=(n+1)%questions.length;render();});render();
