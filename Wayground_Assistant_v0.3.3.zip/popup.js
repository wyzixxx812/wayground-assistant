'use strict';
const DEFAULTS={enabled:true,useAI:false,useWeb:false,visionEnabled:true,opacity:.92,apiKey:'',uiLanguage:'ru'};
const TRANSLATIONS={
  ru:{
    previewTitle:'Внешний вид отметки',
    previewExplanation:'Настройте заметность цветной линии. Предпросмотр обновляется сразу — до сохранения.',
    previewDark:'Пример на тёмном фоне',
    previewLive:'В реальном времени',
    previewAnswer:'Вариант ответа',
    previewEnlarged:'Увеличенный образец',
    previewZoomHint:'Линия увеличена, чтобы было видно изменение на чёрном фоне.',
    previewNote:'На карточке линия шириной 2 пикселя. Ниже — увеличенная копия для сравнения.',
    lineOpacity:'Непрозрачность отметки',
    opacityHint:'Меньше процент — линия слабее; больше — заметнее. На сайте её ширина остаётся 2 пикселя.',
    interfaceLanguage:'Язык интерфейса',languageHint:'Меняет подписи и объяснения, не язык вопросов.',
    pageStatus:'Статус страницы',statusHint:'Показывает, распознан ли вопрос и откуда взята подсказка.',settings:'Настройки',
    enabled:'Включить ассистент',enabledHint:'Находит вопрос при смене задания и показывает отметки.',
    useAI:'Анализ через ИИ',useAIHint:'Проверяет незнакомые вопросы через OpenAI. Нужен API-ключ, запросы могут быть платными.',
    vision:'Распознавание фотографий',visionHint:'Обрабатывает картинку, только если вопрос просит её определить. Требует включённого ИИ и API-ключа.',
    webSearch:'Поиск в интернете',webSearchHint:'Дополнительная проверка фактов при работе с ИИ. Может быть медленнее и дороже.',
    apiTitle:'Подключение OpenAI',keyLabel:'Личный API-ключ',keyHint:'Ключ позволяет обращаться к ИИ; это не пароль от ChatGPT. Не передавайте его другим.',
    getKey:'Ключ можно добыть здесь',guideTitle:'Как получить и использовать ключ',
    guide1:'Откройте ссылку выше и войдите в аккаунт OpenAI, который используете в ChatGPT (через тот же Google, Apple или адрес почты). Можно использовать и другой аккаунт, но ключи и оплата будут отдельными.',
    guide2:'Нажмите Create new secret key, укажите название и создайте ключ.',
    guide3:'Скопируйте ключ при создании: позже полный ключ может быть недоступен.',
    guide4:'Вставьте его в поле выше и включите «Анализ через ИИ».',
    guide5:'При необходимости включите распознавание фото и поиск в интернете, затем нажмите «Сохранить настройки».',
    guide6:'Откройте пробный тест Wayground и проверьте статус расширения.',
    billingWarning:'API может требовать отдельную оплату. Подписка ChatGPT Plus не оплачивает запросы API автоматически.',
    billingLink:'Настройки оплаты API',privacyWarning:'Не храните личный ключ в браузере школьного или общего компьютера. Если вы уже сохранили его там, удалите ключ из расширения и отзовите его в панели OpenAI.',
    apiHint:'Без API работает только встроенная база. Для распознавания фото нужна модель ИИ с поддержкой изображений.',
    save:'Сохранить настройки',demo:'Демонстрация',demoHint:'Тестовая страница для проверки функций.',rescan:'Повторить анализ',rescanHint:'Заново проверяет текущий вопрос.',
    footer:'Отметки — предположение ИИ, а не гарантия. Расширение не нажимает ответы автоматически.',
    saved:'✓ Настройки сохранены',savingError:'Не удалось сохранить настройки',noTab:'Вкладка не найдена',
    demoStatus:'Демонстрация открыта. Переключайте вопросы кнопкой вверху.',demoQuestion:'Текстовые ответы отмечаются локально. Для фото нужен API.',
    pageMissing:'Откройте тест Wayground или демонстрацию.',showKey:'Показать или скрыть ключ'
  },
  en:{
    previewTitle:'Marker appearance',
    previewExplanation:'Adjust how visible the colored line is. The example updates immediately, even before saving.',
    previewDark:'Preview on a dark background',
    previewLive:'Live preview',
    previewAnswer:'Answer choice',
    previewEnlarged:'Magnified sample',
    previewZoomHint:'This line is enlarged to make opacity changes clear on black.',
    previewNote:'The marker on the card is 2 pixels wide. Below is a magnified comparison.',
    lineOpacity:'Marker opacity',
    opacityHint:'Lower percentages make the marker fainter; higher ones make it clearer. Width remains 2 px on the page.',
    interfaceLanguage:'Interface language',languageHint:'Changes labels and explanations, not the question language.',
    pageStatus:'Page status',statusHint:'Shows whether the question was detected and where the suggestion came from.',settings:'Settings',
    enabled:'Enable assistant',enabledHint:'Detects the next question and draws answer markers.',
    useAI:'AI analysis',useAIHint:'Checks unfamiliar questions with OpenAI. Requires an API key and may incur charges.',
    vision:'Image recognition',visionHint:'Analyzes a picture only when the question asks about it. Requires AI and an API key.',
    webSearch:'Web search',webSearchHint:'Optional fact-checking with AI. Can be slower and cost more.',
    apiTitle:'Connect OpenAI',keyLabel:'Personal API key',keyHint:'The key grants access to AI; it is not your ChatGPT password. Do not share it.',
    getKey:'Get your API key here',guideTitle:'How to create and use the key',
    guide1:'Open the link and sign in to the OpenAI account you use for ChatGPT (using the same Google, Apple, or email sign-in). A different account also works, with separate keys and billing.',
    guide2:'Select Create new secret key, give it a name, and create it.',
    guide3:'Copy the key when it appears; you may not be able to see it again.',
    guide4:'Paste the key into the field above and enable “AI analysis”.',
    guide5:'Optionally enable image recognition or web search, then choose “Save settings”.',
    guide6:'Open a practice Wayground quiz and check the extension status.',
    billingWarning:'API use may require separate billing. ChatGPT Plus does not automatically cover API usage.',
    billingLink:'API billing settings',privacyWarning:'Do not save a personal key in a shared or school computer. If you already did, delete it from the extension and revoke it in OpenAI Platform.',
    apiHint:'Without the API, only the built-in knowledge base works. Recognizing photos requires a vision-capable AI model.',
    save:'Save settings',demo:'Open demo',demoHint:'Practice page for testing features.',rescan:'Analyze again',rescanHint:'Re-check the current question.',
    footer:'Markers are suggestions, not guarantees. The extension never clicks answers automatically.',
    saved:'✓ Settings saved',savingError:'Could not save settings',noTab:'No tab found',
    demoStatus:'Demo is open. Use the button at the top to switch questions.',demoQuestion:'Local rules cover text choices; image recognition needs the API.',
    pageMissing:'Open a Wayground quiz or the demo.',showKey:'Show or hide the API key'
  },
  lv:{
    previewTitle:'Atzīmes izskats',
    previewExplanation:'Pielāgojiet krāsainās līnijas redzamību. Priekšskatījums mainās uzreiz, vēl pirms saglabāšanas.',
    previewDark:'Piemērs uz tumša fona',
    previewLive:'Tiešais priekšskatījums',
    previewAnswer:'Atbildes variants',
    previewEnlarged:'Palielināts paraugs',
    previewZoomHint:'Līnija ir palielināta, lai uz melna fona būtu redzamas izmaiņas.',
    previewNote:'Uz kartītes līnija ir 2 pikseļus plata. Zemāk tā palielināta salīdzināšanai.',
    lineOpacity:'Atzīmes necaurspīdīgums',
    opacityHint:'Mazāks procents — blāvāka līnija; lielāks — pamanāmāka. Lapā platums paliek 2 pikseļi.',
    interfaceLanguage:'Saskarnes valoda',languageHint:'Maina izvēlnes tekstu un skaidrojumus, nevis jautājuma valodu.',
    pageStatus:'Lapas statuss',statusHint:'Rāda, vai jautājums ir atpazīts un no kurienes nāk ieteikums.',settings:'Iestatījumi',
    enabled:'Ieslēgt asistentu',enabledHint:'Atpazīst nākamo jautājumu un rāda atbilžu atzīmes.',
    useAI:'MI analīze',useAIHint:'Pārbauda nezināmus jautājumus ar OpenAI. Vajadzīga API atslēga; var būt maksa.',
    vision:'Attēlu atpazīšana',visionHint:'Analizē attēlu tikai tad, ja tas prasīts jautājumā. Vajadzīgs MI un API atslēga.',
    webSearch:'Meklēšana internetā',webSearchHint:'Papildu faktu pārbaude ar MI. Var būt lēnāka un dārgāka.',
    apiTitle:'OpenAI savienojums',keyLabel:'Personīgā API atslēga',keyHint:'Atslēga dod piekļuvi MI; tā nav ChatGPT parole. Neizpaudiet to citiem.',
    getKey:'API atslēgu var iegūt šeit',guideTitle:'Kā iegūt un izmantot atslēgu',
    guide1:'Atveriet saiti un piesakieties OpenAI kontā, ko izmantojat ChatGPT (ar to pašu Google, Apple vai e-pastu). Var izmantot arī citu kontu, taču atslēgas un norēķini būs atsevišķi.',
    guide2:'Nospiediet Create new secret key, piešķiriet nosaukumu un izveidojiet atslēgu.',
    guide3:'Nokopējiet atslēgu uzreiz; vēlāk tā var nebūt pilnībā redzama.',
    guide4:'Ielīmējiet atslēgu augstāk esošajā laukā un ieslēdziet “MI analīze”.',
    guide5:'Ja vajag, ieslēdziet attēlu atpazīšanu un meklēšanu, pēc tam spiediet “Saglabāt iestatījumus”.',
    guide6:'Atveriet Wayground izmēģinājuma testu un pārbaudiet paplašinājuma statusu.',
    billingWarning:'API var būt nepieciešama atsevišķa apmaksa. ChatGPT Plus abonements automātiski nesedz API izmaksas.',
    billingLink:'API norēķinu iestatījumi',privacyWarning:'Neglabājiet personīgo atslēgu skolas vai koplietotā datorā. Ja tā jau saglabāta, izdzēsiet to un atsauciet OpenAI platformā.',
    apiHint:'Bez API darbojas tikai iebūvētā zināšanu bāze. Foto atpazīšanai vajadzīgs MI modelis ar attēlu atbalstu.',
    save:'Saglabāt iestatījumus',demo:'Atvērt demonstrāciju',demoHint:'Izmēģinājuma lapa funkciju pārbaudei.',rescan:'Analizēt vēlreiz',rescanHint:'Atkārtoti pārbauda pašreizējo jautājumu.',
    footer:'Atzīmes ir ieteikumi, nevis garantija. Paplašinājums automātiski neizvēlas atbildes.',
    saved:'✓ Iestatījumi saglabāti',savingError:'Neizdevās saglabāt iestatījumus',noTab:'Cilne nav atrasta',
    demoStatus:'Demonstrācija ir atvērta. Pārslēdziet jautājumus ar pogu augšā.',demoQuestion:'Teksta atbildes pārbauda lokālā bāze; attēliem vajadzīgs API.',
    pageMissing:'Atveriet Wayground testu vai demonstrāciju.',showKey:'Parādīt vai paslēpt API atslēgu'
  }
};
const lang=()=>['ru','en','lv'].includes($('uiLanguage').value)?$('uiLanguage').value:'ru';
const tr=k=>TRANSLATIONS[lang()][k]||TRANSLATIONS.ru[k]||k;
let tabId=null;let savedTimer=null;
function localize() {
  document.documentElement.lang=lang();
  document.querySelectorAll('[data-i18n]').forEach(el=>{el.textContent=tr(el.dataset.i18n);});
  $('showKey').title=tr('showKey');$('showKey').setAttribute('aria-label',tr('showKey'));
  $('getKeyLink').title=tr('getKey');
}
async function load(){
  try{
    const s=await chrome.storage.local.get(DEFAULTS);
    for(const id of ['enabled','useAI','visionEnabled','useWeb'])$(id).checked=id==='enabled'?s.enabled!==false:(id==='visionEnabled'?s.visionEnabled!==false:!!s[id]);
    $('apiKey').value=s.apiKey||'';
    $('uiLanguage').value=['ru','en','lv'].includes(s.uiLanguage)?s.uiLanguage:'ru';
    $('opacity').value=Math.round((s.opacity??.92)*100);
  }catch{}
  localize();showOpacity();await statusRefresh();
}
function showOpacity(){
  $('opacityValue').textContent=$('opacity').value+'%';
  document.querySelectorAll('[data-marker-preview]').forEach(el=>{el.style.opacity=String(Number($('opacity').value)/100);});
}
function $(selector) {return document.getElementById(selector);}
async function statusRefresh(){
  try {
    const tabs=await chrome.tabs.query({active:true,currentWindow:true});
    tabId=tabs[0]?.id??null;if(tabId===null)throw Error(tr('noTab'));
    if(tabs[0]?.url===chrome.runtime.getURL('demo.html')){
      $('status').textContent=tr('demoStatus');$('question').textContent=tr('demoQuestion');
      $('dot').className='status-indicator ready';$('details').hidden=true;return;
    }
    const data=await chrome.tabs.sendMessage(tabId,{type:'GET_STATUS'});
    $('status').textContent=data.message||'…';$('question').textContent=data.question||'';
    $('dot').className='status-indicator'+(data.state==='ready'?' ready':data.state==='error'?' error':'');
    $('details').hidden=!data.explanation;$('source').textContent=data.source||'';$('explanation').textContent=data.explanation||'';
  }catch{
    $('status').textContent=tr('pageMissing');$('question').textContent='';$('details').hidden=true;$('dot').className='status-indicator';
  }
}
$('opacity').addEventListener('input',showOpacity);
$('uiLanguage').addEventListener('change',async()=>{
  localize();
  try {
    await chrome.storage.local.set({uiLanguage:lang()});
    if(tabId!==null)await chrome.tabs.sendMessage(tabId,{type:'SETTINGS_CHANGED'}).catch(()=>{});
  } catch {}
  statusRefresh();
});
$('showKey').addEventListener('click',()=>{$('apiKey').type=$('apiKey').type==='password'?'text':'password';});
$('save').addEventListener('click',async()=>{
  $('saved').textContent='';
  try{
    await chrome.storage.local.set({
      enabled:$('enabled').checked,useAI:$('useAI').checked,visionEnabled:$('visionEnabled').checked,
      useWeb:$('useWeb').checked,uiLanguage:lang(),opacity:Number($('opacity').value)/100,
      apiKey:$('apiKey').value.trim()
    });
    try{if(tabId!==null)await chrome.tabs.sendMessage(tabId,{type:'SETTINGS_CHANGED'});}catch{}
    $('saved').textContent=tr('saved');if(savedTimer)clearTimeout(savedTimer);
    savedTimer=setTimeout(()=>{$('saved').textContent='';},2400);
    statusRefresh();
  }catch(e){$('saved').textContent=`${tr('savingError')}: ${String(e.message||e).slice(0,90)}`;}
});
$('demo').addEventListener('click',()=>chrome.tabs.create({url:chrome.runtime.getURL('demo.html')}));
$('rescan').addEventListener('click',async()=>{
  if(tabId!==null){try{await chrome.tabs.sendMessage(tabId,{type:'RESCAN'});}catch{}}
  statusRefresh();
});
load();setInterval(statusRefresh,1900);
