/* Локальная база для учебных вопросов о БП. Возвращает все совпадения,
   но только если формулировка допускает это и правило достаточно однозначно. */
(() => {
  'use strict';
  function norm(x) {
    return String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();
  }
  const reasons = {
    'Стандартные положительные линии ATX включают +3,3 В, +5 В и +12 В.': [
      'The standard ATX positive rails include +3.3 V, +5 V and +12 V.',
      'Standarta ATX pozitīvās sprieguma līnijas ir +3,3 V, +5 V un +12 V.'],
    'Правило 3-2-1: три копии, два разных типа носителей, одна копия вне основного места.': [
      'The 3-2-1 rule: three copies, two media types, one off-site copy.',
      '3-2-1 princips: trīs kopijas, divu veidu datu nesēji, viena kopija citā vietā.'],
    'Блок питания преобразует сетевой переменный ток в стабилизированные постоянные напряжения для компонентов ПК.': [
      'The power supply converts mains AC into regulated DC voltages for PC components.',
      'Barošanas bloks pārveido tīkla maiņstrāvu stabilizētos līdzstrāvas spriegumos datora komponentiem.'],
    'Основной разъём питания современной ATX-платы — 24 контакта (20+4).': [
      'Modern ATX motherboards use a 24-pin main power connector (20+4).',
      'Mūsdienu ATX mātesplatei parasti ir 24 kontaktu galvenais barošanas savienotājs (20+4).'],
    'Для питания процессора обычно используется EPS 8-pin (4+4).': [
      'CPU power usually uses an 8-pin EPS connector (4+4).',
      'Procesora barošanai parasti izmanto EPS 8 kontaktu savienotāju (4+4).'],
    'Стандартный разъём SATA Power имеет 15 контактов.': [
      'A standard SATA power connector has 15 pins.',
      'Standarta SATA barošanas savienotājam ir 15 kontakti.'],
    'Сертификация 80 PLUS относится к энергоэффективности блока питания.': [
      '80 PLUS certification is about PSU energy efficiency.',
      '80 PLUS sertifikācija raksturo barošanas bloka energoefektivitāti.'],
    'У модульного блока питания неиспользуемые кабели можно отсоединять.': [
      'A modular PSU allows unused cables to be disconnected.',
      'Modulāram barošanas blokam nevajadzīgos kabeļus var atvienot.'],
    'PFC — коррекция коэффициента мощности.': [
      'PFC stands for power factor correction.',
      'PFC nozīmē jaudas koeficienta korekciju.'],
    'Линия +12 В питает основные высокомощные узлы, включая CPU и GPU.': [
      'The +12 V rail powers major high-draw components including CPU and GPU.',
      '+12 V līnija baro jaudīgus komponentus, tostarp CPU un GPU.'],
    'Номинальная мощность БП указывается в ваттах (Вт).': [
      'A PSU’s rated power is measured in watts (W).',
      'Barošanas bloka nominālo jaudu mēra vatos (W).'],
    'Три резервные копии, два типа носителей, одна копия в другом месте.': [
      'Three backup copies, two media types, one copy in another location.',
      'Trīs rezerves kopijas, divu veidu datu nesēji, viena kopija citā vietā.']
  };
  const translateReason=(value,language)=>language==='en'?(reasons[value]?.[0]||value):
    language==='lv'?(reasons[value]?.[1]||value):value;
  function answer(question, options, mode = 'unknown', language = 'ru') {
    const q = norm(question), os = options.map(norm);
    const rules = [
      {
        // Показательный вопрос, в котором несколько правильных напряжений.
        question: /(?:spriegum|voltage|напряжен).*(?:atx|barosan|psu|power supply|блок|standart)|(?:atx|barosan|psu|power supply|блок).*(?:spriegum|voltage|напряжен)/,
        option: /(?:^|\s|\+)(?:3[,.]3|5|12)\s*(?:v|volti|volt|вольт|в)(?:\b|$)/,
        reason: 'Стандартные положительные линии ATX включают +3,3 В, +5 В и +12 В.'
      },
      {
        question: /3\s*[-–—]\s*2\s*[-–—]\s*1|3 2 1.*(backup|rezerv|копи)/,
        option: /3\s+(kopij|copies|копи)/,
        check: t => /2\s+(datu nesej|media|nositel|носител)/.test(t) && /1\s+(cita vieta|offsite|different location|друг)/.test(t),
        reason: 'Правило 3-2-1: три копии, два разных типа носителей, одна копия вне основного места.'
      },
      {
        question: /(barosanas blok|power supply|psu|блок питания|\bбп\b).*(funkc|uzdevum|paredzet|назначен|делает|преобраз|what.*do|purpose)|(?:funkc|uzdevum|paredzet|назначен|делает|purpose).*(barosanas blok|power supply|psu|блок питания)/,
        option: /(mainstrav|alternating current|\bac\b|переменн).*(lidzstrav|direct current|\bdc\b|постоянн)|(?:ac to dc|ac–dc|ac-dc)|питани[ея] компонент|nodrosina.*(spriegum|barosan)/,
        reason: 'Блок питания преобразует сетевой переменный ток в стабилизированные постоянные напряжения для компонентов ПК.'
      },
      {
        question: /(24\s*pin|24\s*контакт|24\s*kontaktu|atx.*(galven|main|основн)|motherboard.*(power|connector)|материнск.*(разъем|разъём|питан|atx))/,
        option: /\b24\b|20\s*\+\s*4/,
        reason: 'Основной разъём питания современной ATX-платы — 24 контакта (20+4).'
      },
      {
        question: /(cpu|processor|процессор|procesor).*(eps|barosan|pitan|питан|connector|разъем|разъём|savienot)|(?:eps|barosan|pitan|питан|connector|разъем|разъём|savienot).*(cpu|processor|процессор|procesor)/,
        option: /(4\s*\+\s*4|8\s*[- ]?pin|eps\s*12v)/,
        reason: 'Для питания процессора обычно используется EPS 8-pin (4+4).'
      },
      {
        question: /(sata).*(pitan|питан|barosan|power).*(kontak|pin|контакт|разъём|разъем)|(?:pin|контакт|kontak).*(sata.*power|sata.*питан)/,
        option: /\b15\b/,
        reason: 'Стандартный разъём SATA Power имеет 15 контактов.'
      },
      {
        question: /(80\s*plus).*(nozim|означ|meaning|certif|sertifik|apliecin|indic|эффектив|efficien|lietder)/,
        option: /(эффектив|кпд|lietder|efficien|energoefektiv)/,
        reason: 'Сертификация 80 PLUS относится к энергоэффективности блока питания.'
      },
      {
        question: /(modular|modulara|модульн).*(psu|blok|блок|barosan|kabel|кабел|vadu)/,
        option: /(atvien|отсоедин|съемн|съёмн|detachable|removable|disconnect|noņem)/,
        reason: 'У модульного блока питания неиспользуемые кабели можно отсоединять.'
      },
      {
        question: /(pfc|power factor correction|коэффициент мощности|jaudas koeficient)/,
        option: /(power factor|koeficient|коэффициент мощности|jaudas koeficient)/,
        reason: 'PFC — коррекция коэффициента мощности.'
      },
      {
        question: /(\+?12\s*v|12\s*volt|12\s*в).*(cpu|gpu|processor|videokart|видеокарт|процессор)/,
        option: /(cpu|gpu|processor|videokart|видеокарт|процессор)/,
        reason: 'Линия +12 В питает основные высокомощные узлы, включая CPU и GPU.'
      },
      {
        question: /(watt|вати|ватт|jauda|мощност|power rating).*(psu|barosan|блок|bloka|supply)/,
        option: /(watt|ватт|vati|\bw\b|vatos|ватах)/,
        reason: 'Номинальная мощность БП указывается в ваттах (Вт).'
      }
    ];
    for (const r of rules) {
      if (!r.question.test(q)) continue;
      const matches = [];
      os.forEach((t, index) => { if (r.option.test(t) && (!r.check || r.check(t))) matches.push(index); });
      if (matches.length && (matches.length === 1 || mode !== 'single')) {
        return {indices:matches, confidence:matches.length>1 ? 0.90 : 0.93,
          explanation:translateReason(r.reason,language), source:language==='en'?'Local knowledge':language==='lv'?'Lokālā bāze':'Локальная база'};
      }
    }
    // Дополнительная проверка вопроса по скриншоту: резервное копирование 3-2-1.
    if (/3\s*[-–—]\s*2\s*[-–—]\s*1/.test(q)) {
      const matches = os.flatMap((t, i) =>
        /3\s+kopij/.test(t) && /2\s+datu nesej/.test(t) && /1\s+cita vieta/.test(t) ? [i] : []);
      if (matches.length === 1) return {indices: matches, confidence: 0.99,
        explanation: translateReason('Три резервные копии, два типа носителей, одна копия в другом месте.',language), source:language==='en'?'Local knowledge':language==='lv'?'Lokālā bāze':'Локальная база'};
    }
    return null;
  }
  globalThis.QuizKnowledge = Object.freeze({answer, norm});
})();
